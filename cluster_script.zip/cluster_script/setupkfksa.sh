#!/bin/bash

# ===============================================================================================
# Component			Port			Original Port
# ===============================================================================================
# ZooKeeper			3100,3200,3300		2181,2888,3888
# Kafka brokers (plain text)	3400,3401,3402		9092
#				3403,3404,3405		8090
# Schema Registry REST API	3500			8081
# Kafka Connect REST API	3600			8083
# REST Proxy			3700			8082
# KSQL Server REST API		3800			8088
# Metadata Service (MDS)	3900			8090
# Confluent Control Center	4000			9021
# ZooNavigator			4100,4200
# Kafka-Manager (CMAK)		4210
# Kafka-Monitor			8778
# Kafka JMX Exporter		4215			8080
# 				4220,4221,4222		8080
# Prometheus			4230			9090
# Grafana			4240			3000
# MySQL				3306			3306
# ===============================================================================================
# Confluent Control Center	http://ec2-3-238-24-232.compute-1.amazonaws.com:4000
# Schema Registry REST API	http://ec2-3-238-24-232.compute-1.amazonaws.com:3500
# Kafka Connect REST API	http://ec2-3-238-24-232.compute-1.amazonaws.com:3600
# REST Proxy			http://ec2-3-238-24-232.compute-1.amazonaws.com:3700
# KSQL Server REST API		http://ec2-3-238-24-232.compute-1.amazonaws.com:3800
# ZooNavigator			http://ec2-3-238-24-232.compute-1.amazonaws.com:4200
#				3.238.24.232:3100
# Kafka-Manager			http://3.238.24.232:4210
#				3.238.24.232:3100
# Kafka-Monitor			http://ec2-3-238-24-232.compute-1.amazonaws.com:8778/jolokia/read/kmf.services:type=produce-service,name=*/produce-availability-avg
# Kafka JMX Exporter		http://ec2-3-238-24-232.compute-1.amazonaws.com:4215
#				http://ec2-3-238-24-232.compute-1.amazonaws.com:4220
#				http://ec2-3-238-24-232.compute-1.amazonaws.com:4221
#				http://ec2-3-238-24-232.compute-1.amazonaws.com:4222
# Prometheus			http://ec2-3-238-24-232.compute-1.amazonaws.com:4230
# Grafana			http://ec2-3-238-24-232.compute-1.amazonaws.com:4240
#				(Default Prometheus Based Kafka Dashboard No 721)
# MySQL				mysql -u mysqluser -pmysqluser123 -h ec2-3-238-24-232.compute-1.amazonaws.com
# ===============================================================================================
# nano /work/kafka/confluent-6.2.0/etc/kafka/zookeeper.properties
# nano /work/kafka/confluent-6.2.0/etc/kafka/server1.properties
# nano /work/kafka/confluent-6.2.0/etc/kafka/server2.properties
# nano /work/kafka/confluent-6.2.0/etc/kafka/server3.properties
# nano /work/kafka/confluent-6.2.0/etc/schema-registry/schema-registry.properties
# nano /work/kafka/confluent-6.2.0/etc/kafka/connect-distributed.properties
# nano /work/kafka/confluent-6.2.0/etc/schema-registry/connect-avro-distributed.properties
# nano /work/kafka/confluent-6.2.0/etc/kafka-rest/kafka-rest.properties
# nano /work/kafka/confluent-6.2.0/etc/ksqldb/ksql-server.properties
# nano /work/kafka/confluent-6.2.0/etc/ksqldb/connect.properties
# nano /work/kafka/confluent-6.2.0/etc/confluent-control-center/control-center-minimal.properties
# nano /work/kafka/monitor/config/xinfra-monitor.properties
# nano /work/kafka/prometheus/core/prometheus.yml
# nano /work/kafka/prometheus/grafana/conf/defaults.ini
# ===============================================================================================
# sudo systemctl status kafka-zookeeper
# sudo systemctl status kafka-broker1
# sudo systemctl status kafka-broker2
# sudo systemctl status kafka-broker3
# sudo systemctl status kafka-schema-registry
# sudo systemctl status kafka-connect
# sudo systemctl status kafka-rest
# sudo systemctl status kafka-ksql-server
# sudo systemctl status kafka-control-center
# sudo systemctl status docker-compose@zoonavigator
# sudo systemctl status docker-compose@kafka-manager
# sudo systemctl status kafka-monitor
# sudo systemctl status kafka-prometheus
# sudo systemctl status kafka-grafana
# ===============================================================================================

THESYSTEMHOSTNAME=$1
THESYSTEMHOSTIP=$2
THEHOSTNAME=$(hostname)
THEUSERNAME=$(whoami)
THEUSERDIR=$(pwd)

sudo yum install -y sudo && sudo rm -f /var/lib/rpm/__db* && sudo db_verify /var/lib/rpm/Packages && sudo rpm --rebuilddb && sudo yum clean all && sudo rm -rf /var/cache/yum && sudo yum update -y && sudo yum upgrade -y && sudo yum install -y epel-release pxz nano axel curl e2fsprogs ethtool gzip hwdata nano ncdu nmap ntp ntpdate openldap openssh openssl parted rsync telnet tzdata unzip wget xfsprogs xz p7zip net-tools openssh-clients openssh-server iproute redhat-lsb-core NetworkManager-tui nano axel curl e2fsprogs ethtool gzip hwdata nano ncdu nmap ntp ntpdate openldap openssh openssl parted rsync telnet tzdata unzip wget xfsprogs xz p7zip deltarpm p7zip-plugins epel-release pxz nano axel curl e2fsprogs ethtool gzip hwdata nano ncdu nmap ntp ntpdate openldap openssh openssl parted rsync telnet tzdata unzip wget xfsprogs xz p7zip net-tools openssh-clients openssh-server iproute redhat-lsb-core NetworkManager-tui nano axel curl e2fsprogs ethtool gzip hwdata nano ncdu nmap ntp ntpdate openldap openssh openssl parted rsync telnet tzdata unzip wget xfsprogs xz p7zip deltarpm p7zip-plugins jq gcc openssl-devel bzip2-devel libffi-devel zlib-devel sshpass p7zip p7zip-plugins epel-release pxz nano axel curl e2fsprogs ethtool gzip hwdata nano ncdu nmap ntp ntpdate openldap openssh openssl parted rsync telnet tzdata unzip wget xfsprogs xz p7zip net-tools openssh-clients openssh-server iproute redhat-lsb-core NetworkManager-tui nano axel curl e2fsprogs ethtool gzip hwdata nano ncdu nmap ntp ntpdate openldap openssh openssl parted rsync telnet tzdata unzip wget xfsprogs xz p7zip deltarpm epel-release pxz nano axel curl e2fsprogs ethtool gzip hwdata nano ncdu nmap ntp ntpdate openldap openssh openssl parted rsync telnet tzdata unzip wget xfsprogs xz p7zip net-tools openssh-clients openssh-server iproute redhat-lsb-core NetworkManager-tui nano axel curl e2fsprogs ethtool gzip hwdata nano ncdu nmap ntp ntpdate openldap openssh openssl parted rsync telnet tzdata unzip wget xfsprogs xz p7zip deltarpm yum-utils git python-pip ntp openssh-clients openssh-server iproute redhat-lsb-core NetworkManager-tui nano axel curl e2fsprogs ethtool gzip hwdata nano ncdu nmap ntp ntpdate openldap openssh openssl parted rsync telnet tzdata unzip wget xfsprogs xz p7zip deltarpm pxz nano axel curl e2fsprogs ethtool gzip hwdata nano ncdu nmap ntp ntpdate openldap openssh openssl parted rsync telnet tzdata unzip wget xfsprogs xz p7zip net-tools iptables firewalld && sudo rm -f /var/lib/rpm/__db* && sudo db_verify /var/lib/rpm/Packages && sudo rpm --rebuilddb && sudo yum clean all && sudo rm -rf /var/cache/yum && sudo yum update -y && sudo yum upgrade -y && sudo systemctl stop iptables && sudo systemctl disable iptables && sudo systemctl mask iptables && sudo systemctl stop firewalld && sudo systemctl disable firewalld

sudo setenforce 0
sudo sed -i 's/^SELINUX=enforcing$/SELINUX=permissive/' /etc/selinux/config
sudo yum -y install epel-release
sudo yum install -y jq openssh-server openssh-clients sshpass curl wget haproxy ca-certificates curl gnupg gnupg2 corosync pcs pacemaker haproxy haveged
sudo yum install -y yum-utils
sudo rm -rf /etc/yum.repos.d/hashicorp.repo
release="RHEL" && sudo yum-config-manager --add-repo https://rpm.releases.hashicorp.com/$release/hashicorp.repo
sudo yum install -y terraform
sudo rm -rf /etc/yum.repos.d/docker-ce.repo
sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
sudo yum install -y docker-ce docker-ce-cli containerd.io
sudo mkdir -p /etc/docker && sudo rm -rf /etc/docker/daemon.json && echo "{
\"exec-opts\": [\"native.cgroupdriver=systemd\"],
\"log-driver\": \"json-file\",
\"log-opts\": {
\"max-size\": \"100m\"
},
\"storage-driver\": \"overlay2\"
}" | sudo tee /etc/docker/daemon.json > /dev/null	
sudo systemctl enable docker && sudo systemctl daemon-reload && sudo systemctl restart docker && sudo docker run hello-world
sudo rm -rf /etc/yum.repos.d/kubernetes.repo
echo "[kubernetes]
name=Kubernetes
baseurl=https://packages.cloud.google.com/yum/repos/kubernetes-el7-x86_64
enabled=1
gpgcheck=0
repo_gpgcheck=0
gpgkey=https://packages.cloud.google.com/yum/doc/yum-key.gpg https://packages.cloud.google.com/yum/doc/rpm-package-key.gpg" | sudo tee /etc/yum.repos.d/kubernetes.repo > /dev/null
sudo yum install -y kubelet kubeadm kubectl --disableexcludes=kubernetes
sudo systemctl enable --now kubelet
sudo sed -i "s/GSSAPIAuthentication/#GSSAPIAuthentication/g" /etc/ssh/sshd_config
sudo sed -i "s/GSSAPICleanupCredentials/#GSSAPICleanupCredentials/g" /etc/ssh/sshd_config
sudo sed -i "s/AuthorizedKeysFile/#AuthorizedKeysFile/g" /etc/ssh/sshd_config
echo "AuthorizedKeysFile %h/.ssh/authorized_keys" | sudo tee -a /etc/ssh/sshd_config > /dev/null
sudo systemctl restart sshd
sudo systemctl status sshd
sudo yum install -y firewalld
sudo service firewalld stop
sudo service firewalld status
sudo setenforce 0
sudo sed -i 's/^SELINUX=enforcing$/SELINUX=disabled/' /etc/selinux/config

sudo yum install -y epel-release pxz nano axel curl e2fsprogs ethtool gzip hwdata nano ncdu nmap ntp ntpdate openldap openssh openssl parted rsync telnet tzdata unzip wget xfsprogs xz p7zip net-tools openssh-clients openssh-server iproute redhat-lsb-core NetworkManager-tui nano axel curl e2fsprogs ethtool gzip hwdata nano ncdu nmap ntp ntpdate openldap openssh openssl parted rsync telnet tzdata unzip wget xfsprogs xz p7zip deltarpm p7zip-plugins epel-release pxz nano axel curl e2fsprogs ethtool gzip hwdata nano ncdu nmap ntp ntpdate openldap openssh openssl parted rsync telnet tzdata unzip wget xfsprogs xz p7zip net-tools openssh-clients openssh-server iproute redhat-lsb-core NetworkManager-tui nano axel curl e2fsprogs ethtool gzip hwdata nano ncdu nmap ntp ntpdate openldap openssh openssl parted rsync telnet tzdata unzip wget xfsprogs xz p7zip deltarpm p7zip-plugins jq gcc openssl-devel bzip2-devel libffi-devel zlib-devel sshpass p7zip p7zip-plugins epel-release pxz nano axel curl e2fsprogs ethtool gzip hwdata nano ncdu nmap ntp ntpdate openldap openssh openssl parted rsync telnet tzdata unzip wget xfsprogs xz p7zip net-tools openssh-clients openssh-server iproute redhat-lsb-core NetworkManager-tui nano axel curl e2fsprogs ethtool gzip hwdata nano ncdu nmap ntp ntpdate openldap openssh openssl parted rsync telnet tzdata unzip wget xfsprogs xz p7zip deltarpm epel-release pxz nano axel curl e2fsprogs ethtool gzip hwdata nano ncdu nmap ntp ntpdate openldap openssh openssl parted rsync telnet tzdata unzip wget xfsprogs xz p7zip net-tools openssh-clients openssh-server iproute redhat-lsb-core NetworkManager-tui nano axel curl e2fsprogs ethtool gzip hwdata nano ncdu nmap ntp ntpdate openldap openssh openssl parted rsync telnet tzdata unzip wget xfsprogs xz p7zip deltarpm yum-utils git python-pip ntp openssh-clients openssh-server iproute redhat-lsb-core NetworkManager-tui nano axel curl e2fsprogs ethtool gzip hwdata nano ncdu nmap ntp ntpdate openldap openssh openssl parted rsync telnet tzdata unzip wget xfsprogs xz p7zip deltarpm pxz nano axel curl e2fsprogs ethtool gzip hwdata nano ncdu nmap ntp ntpdate openldap openssh openssl parted rsync telnet tzdata unzip wget xfsprogs xz p7zip net-tools iptables firewalld

sudo systemctl stop firewalld
sudo systemctl disable firewalld
sudo systemctl stop iptables
sudo systemctl disable iptables
sudo yum install -y openssh-clients openssh-server iproute redhat-lsb-core NetworkManager-tui nano axel curl e2fsprogs ethtool gzip hwdata nano ncdu nmap ntp ntpdate openldap openssh openssl parted rsync telnet tzdata unzip wget xfsprogs xz p7zip deltarpm pxz nano axel curl e2fsprogs ethtool gzip hwdata nano ncdu nmap ntp ntpdate openldap openssh openssl parted rsync telnet tzdata unzip wget xfsprogs xz p7zip net-tools mysql
wget http://repo.mysql.com/mysql-community-release-el7-5.noarch.rpm
sudo rpm -ivh mysql-community-release-el7-5.noarch.rpm
sudo rm -rf mysql-community-release-el7-5.noarch.rpm
wget https://dev.mysql.com/get/Downloads/Connector-J/mysql-connector-java-5.1.46.tar.gz
tar zxf mysql-connector-java-5.1.46.tar.gz
sudo mkdir -p /usr/share/java/
sudo rm -rf /usr/share/java/mysql-connector-java.jar
cd mysql-connector-java-5.1.46
sudo cp mysql-connector-java-5.1.46-bin.jar /usr/share/java/mysql-connector-java.jar
cd ..
rm -rf mysql-connector-java-5.1.46
rm -f mysql-connector-java-5.1.46.tar.gz
sudo yum install ntp -y
sudo systemctl enable ntpd && sudo service ntpd stop && date -R && sudo ntpdate 0.pool.ntp.org && sudo service ntpd start && date -R
sudo -H -u root bash -c 'sudo echo never > /sys/kernel/mm/transparent_hugepage/enabled'
sudo -H -u root bash -c 'echo never > /sys/kernel/mm/transparent_hugepage/defrag'
sudo -H -u root bash -c 'echo "echo never > /sys/kernel/mm/transparent_hugepage/enabled" >> /etc/rc.d/rc.local'
sudo -H -u root bash -c 'echo "echo never > /sys/kernel/mm/transparent_hugepage/defrag" >> /etc/rc.d/rc.local'
sudo -H -u root bash -c 'chmod u+x /etc/rc.d/rc.local'
sudo -H -u root bash -c 'cat /proc/sys/vm/swappiness'
sudo -H -u root bash -c 'sudo sysctl vm.swappiness=10'
sudo -H -u root bash -c 'cat /proc/sys/vm/swappiness'
sudo -H -u root bash -c 'echo "vm.swappiness=10" >> /etc/sysctl.conf'
sudo usermod -a -G docker $THEUSERNAME
sudo yum install docker-compose git python-pip -y

sudo yum install mysql-server -y
sudo systemctl start mysqld
sudo systemctl stop mysqld

sudo rm -rf /etc/my.cnf

echo "[mysqld]
datadir=/var/lib/mysql
socket=/var/lib/mysql/mysql.sock
transaction-isolation = READ-COMMITTED
# Disabling symbolic-links is recommended to prevent assorted security risks;
# to do so, uncomment this line:
symbolic-links = 0

key_buffer_size = 32M
max_allowed_packet = 16M
thread_stack = 256K
thread_cache_size = 64
query_cache_limit = 8M
query_cache_size = 64M
query_cache_type = 1

max_connections = 550
#expire_logs_days = 10
#max_binlog_size = 100M

#log_bin should be on a disk with enough free space.
#Replace '/var/lib/mysql/mysql_binary_log' with an appropriate path for your
#system and chown the specified folder to the mysql user.
log_bin=/var/lib/mysql/mysql_binary_log

#In later versions of MySQL, if you enable the binary log and do not set
#a server_id, MySQL will not start. The server_id must be unique within
#the replicating group.
server_id=1

binlog_format = mixed

read_buffer_size = 2M
read_rnd_buffer_size = 16M
sort_buffer_size = 8M
join_buffer_size = 8M

# InnoDB settings
innodb_file_per_table = 1
innodb_flush_log_at_trx_commit  = 2
innodb_log_buffer_size = 64M
innodb_buffer_pool_size = 4G
innodb_thread_concurrency = 8
innodb_flush_method = O_DIRECT
innodb_log_file_size = 512M

[mysqld_safe]
log-error=/var/log/mysqld.log
pid-file=/var/run/mysqld/mysqld.pid

sql_mode=STRICT_ALL_TABLES" | sudo tee /etc/my.cnf > /dev/null

sudo chown -R root:root /etc/my.cnf
sudo chmod -R u=rw,g=r,o=r /etc/my.cnf

sudo systemctl enable mysqld
sudo systemctl start mysqld
/usr/bin/mysql_secure_installation <<EOF

y
secret
secret
y
y
y
y
EOF

sudo rm -rf base.sql
echo "
CREATE DATABASE retail_db DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;

CREATE USER 'mysqluser'@'%' IDENTIFIED BY 'mysqluser123';
grant all on retail_db.* to 'mysqluser'@'%' identified by 'mysqluser123';" | sudo tee base.sql > /dev/null
sudo chmod 777 base.sql
mysql -u root -psecret mysql < base.sql
sudo rm -rf base.sql
sudo rm -rf retail_db.sql
wget https://raw.githubusercontent.com/nitendragautam/samp_data_sets/master/retail_data/retail_db.sql
mysql -u root -psecret retail_db < retail_db.sql
sudo rm -rf retail_db.sql

sudo rm -rf *
axel -n 50 https://pilotfiber.dl.sourceforge.net/project/getprathamos/MATSYA/kfk.7z
axel -n 50 https://packages.confluent.io/archive/6.2/confluent-6.2.0.zip
sudo chmod 777 kfk.7z && 7za x kfk.7z -o. && sudo chmod -R 777 Software && mv Software/* . && rm -rf Software && rm -rf kfk.7z
sudo rm -rf confluent-6.1.1.zip
sudo chmod 777 confluent-6.2.0.zip
./setupjdkglobal.sh

kill $(ps aux | grep '[z]ookeeper.properties' | awk '{print $2}')
kill $(ps aux | grep '[s]erver1.properties' | awk '{print $2}')
kill $(ps aux | grep '[s]erver2.properties' | awk '{print $2}')
kill $(ps aux | grep '[s]erver3.properties' | awk '{print $2}')
kill $(ps aux | grep '[s]chema-registry.properties' | awk '{print $2}')
kill $(ps aux | grep '[c]onnect-avro-distributed.properties' | awk '{print $2}')
kill $(ps aux | grep '[k]afka-rest.properties' | awk '{print $2}')
kill $(ps aux | grep '[k]sql-server.properties' | awk '{print $2}')
kill $(ps aux | grep '[c]ontrol-center-minimal.properties' | awk '{print $2}')

sudo systemctl stop kafka-zookeeper && sudo systemctl disable kafka-zookeeper
sudo systemctl stop kafka-broker1 && sudo systemctl disable kafka-broker1
sudo systemctl stop kafka-broker2 && sudo systemctl disable kafka-broker2
sudo systemctl stop kafka-broker3 && sudo systemctl disable kafka-broker3
sudo systemctl stop kafka-schema-registry && sudo systemctl disable kafka-schema-registry
sudo systemctl stop kafka-connect && sudo systemctl disable kafka-connect
sudo systemctl stop kafka-rest && sudo systemctl disable kafka-rest
sudo systemctl stop kafka-ksql-server && sudo systemctl disable kafka-ksql-server
sudo systemctl stop kafka-control-center && sudo systemctl disable kafka-control-center
sudo systemctl stop kafka-monitor && sudo systemctl disable kafka-monitor
sudo systemctl stop kafka-prometheus && sudo systemctl disable kafka-prometheus
sudo systemctl stop kafka-grafana && sudo systemctl disable kafka-grafana

sudo rm -rf /etc/systemd/system/kafka-zookeeper.service
sudo rm -rf /etc/systemd/system/kafka-broker1.service
sudo rm -rf /etc/systemd/system/kafka-broker2.service
sudo rm -rf /etc/systemd/system/kafka-broker3.service
sudo rm -rf /etc/systemd/system/kafka-schema-registry.service
sudo rm -rf /etc/systemd/system/kafka-connect.service
sudo rm -rf /etc/systemd/system/kafka-rest.service
sudo rm -rf /etc/systemd/system/kafka-ksql-server.service
sudo rm -rf /etc/systemd/system/kafka-control-center.service
sudo rm -rf /etc/systemd/system/kafka-monitor.service
sudo rm -rf /etc/systemd/system/kafka-prometheus.service
sudo rm -rf /etc/systemd/system/kafka-grafana.service

echo "[Unit]
Description=Kafka ZooKeeper
After=network.target

[Service]
User=$THEUSERNAME
Group=$THEUSERNAME
WorkingDirectory=$THEUSERDIR
Environment=\"EXTRA_ARGS=-javaagent:/work/kafka/prometheus/jmx_prometheus_javaagent-0.15.0.jar=4215:/work/kafka/prometheus/zookeeper.yaml\"
ExecStart=/work/kafka/confluent-6.2.0/bin/zookeeper-server-start /work/kafka/confluent-6.2.0/etc/kafka/zookeeper.properties
SuccessExitStatus=143

[Install]
WantedBy=multi-user.target" | sudo tee /etc/systemd/system/kafka-zookeeper.service > /dev/null
	
echo "[Unit]
Description=Kafka Broker
After=network.target

[Service]
User=$THEUSERNAME
Group=$THEUSERNAME
WorkingDirectory=$THEUSERDIR
Environment=\"KAFKA_OPTS=-javaagent:/work/kafka/prometheus/jmx_prometheus_javaagent-0.15.0.jar=4220:/work/kafka/prometheus/kafka-0-8-2.yml\"
ExecStart=/work/kafka/confluent-6.2.0/bin/kafka-server-start /work/kafka/confluent-6.2.0/etc/kafka/server1.properties
SuccessExitStatus=143

[Install]
WantedBy=multi-user.target" | sudo tee /etc/systemd/system/kafka-broker1.service > /dev/null
echo "[Unit]
Description=Kafka Broker
After=network.target

[Service]
User=$THEUSERNAME
Group=$THEUSERNAME
WorkingDirectory=$THEUSERDIR
Environment=\"KAFKA_OPTS=-javaagent:/work/kafka/prometheus/jmx_prometheus_javaagent-0.15.0.jar=4221:/work/kafka/prometheus/kafka-0-8-2.yml\"
ExecStart=/work/kafka/confluent-6.2.0/bin/kafka-server-start /work/kafka/confluent-6.2.0/etc/kafka/server2.properties
SuccessExitStatus=143

[Install]
WantedBy=multi-user.target" | sudo tee /etc/systemd/system/kafka-broker2.service > /dev/null
echo "[Unit]
Description=Kafka Broker
After=network.target

[Service]
User=$THEUSERNAME
Group=$THEUSERNAME
WorkingDirectory=$THEUSERDIR
Environment=\"KAFKA_OPTS=-javaagent:/work/kafka/prometheus/jmx_prometheus_javaagent-0.15.0.jar=4222:/work/kafka/prometheus/kafka-0-8-2.yml\"
ExecStart=/work/kafka/confluent-6.2.0/bin/kafka-server-start /work/kafka/confluent-6.2.0/etc/kafka/server3.properties
SuccessExitStatus=143

[Install]
WantedBy=multi-user.target" | sudo tee /etc/systemd/system/kafka-broker3.service > /dev/null

echo "[Unit]
Description=Kafka Schema Registry
After=network.target

[Service]
User=$THEUSERNAME
Group=$THEUSERNAME
WorkingDirectory=$THEUSERDIR
ExecStart=/work/kafka/confluent-6.2.0/bin/schema-registry-start /work/kafka/confluent-6.2.0/etc/schema-registry/schema-registry.properties
SuccessExitStatus=143

[Install]
WantedBy=multi-user.target" | sudo tee /etc/systemd/system/kafka-schema-registry.service > /dev/null

echo "[Unit]
Description=Kafka Connect
After=network.target

[Service]
User=$THEUSERNAME
Group=$THEUSERNAME
WorkingDirectory=$THEUSERDIR
ExecStart=/work/kafka/confluent-6.2.0/bin/connect-distributed /work/kafka/confluent-6.2.0/etc/schema-registry/connect-avro-distributed.properties
SuccessExitStatus=143

[Install]
WantedBy=multi-user.target" | sudo tee /etc/systemd/system/kafka-connect.service > /dev/null

echo "[Unit]
Description=Kafka REST API
After=network.target

[Service]
User=$THEUSERNAME
Group=$THEUSERNAME
WorkingDirectory=$THEUSERDIR
ExecStart=/work/kafka/confluent-6.2.0/bin/kafka-rest-start /work/kafka/confluent-6.2.0/etc/kafka-rest/kafka-rest.properties
SuccessExitStatus=143

[Install]
WantedBy=multi-user.target" | sudo tee /etc/systemd/system/kafka-rest.service > /dev/null

echo "[Unit]
Description=Kafka KSQL
After=network.target

[Service]
User=$THEUSERNAME
Group=$THEUSERNAME
WorkingDirectory=$THEUSERDIR
ExecStart=/work/kafka/confluent-6.2.0/bin/ksql-server-start /work/kafka/confluent-6.2.0/etc/ksqldb/ksql-server.properties
SuccessExitStatus=143

[Install]
WantedBy=multi-user.target" | sudo tee /etc/systemd/system/kafka-ksql-server.service > /dev/null

echo "[Unit]
Description=Kafka Control Center
After=network.target

[Service]
User=$THEUSERNAME
Group=$THEUSERNAME
WorkingDirectory=$THEUSERDIR
ExecStart=/work/kafka/confluent-6.2.0/bin/control-center-start /work/kafka/confluent-6.2.0/etc/confluent-control-center/control-center-minimal.properties
SuccessExitStatus=143

[Install]
WantedBy=multi-user.target" | sudo tee /etc/systemd/system/kafka-control-center.service > /dev/null

echo "[Unit]
Description=Kafka Monitor
After=network.target

[Service]
User=$THEUSERNAME
Group=$THEUSERNAME
WorkingDirectory=$THEUSERDIR
ExecStart=/work/kafka/monitor/bin/xinfra-monitor-start.sh /work/kafka/monitor/config/xinfra-monitor.properties
SuccessExitStatus=143

[Install]
WantedBy=multi-user.target" | sudo tee /etc/systemd/system/kafka-monitor.service > /dev/null

echo "[Unit]
Description=Kafka Prometheus
After=network.target

[Service]
User=$THEUSERNAME
Group=$THEUSERNAME
WorkingDirectory=$THEUSERDIR
ExecStart=/work/kafka/prometheus/core/prometheus --config.file=/work/kafka/prometheus/core/prometheus.yml --web.enable-admin-api --web.listen-address=:4230 --storage.tsdb.path=/work/kafka/prometheus/core/data
SuccessExitStatus=143

[Install]
WantedBy=multi-user.target" | sudo tee /etc/systemd/system/kafka-prometheus.service > /dev/null

echo "[Unit]
Description=Kafka Grafana
After=network.target

[Service]
User=$THEUSERNAME
Group=$THEUSERNAME
WorkingDirectory=/work/kafka/prometheus/grafana
ExecStart=/work/kafka/prometheus/grafana/bin/grafana-server
SuccessExitStatus=143

[Install]
WantedBy=multi-user.target" | sudo tee /etc/systemd/system/kafka-grafana.service > /dev/null

sudo rm -rf /etc/systemd/system/docker-compose@.service
sudo mkdir -p /etc/docker/compose
echo "# /etc/systemd/system/docker-compose@.service
# From: https://github.com/docker/compose/issues/4266#issuecomment-302813256
[Unit]
Description=%i service with docker compose
Requires=docker.service
After=docker.service

[Service]
Restart=always

WorkingDirectory=/etc/docker/compose/%i

# Remove old containers, images and volumes
ExecStartPre=/usr/bin/docker-compose down -v
ExecStartPre=/usr/bin/docker-compose rm -fv
ExecStartPre=-/bin/bash -c 'docker volume ls -qf \"name=%i_\" | xargs docker volume rm'
ExecStartPre=-/bin/bash -c 'docker network ls -qf \"name=%i_\" | xargs docker network rm'
ExecStartPre=-/bin/bash -c 'docker ps -aqf \"name=%i_*\" | xargs docker rm'

# Compose up
ExecStart=/usr/bin/docker-compose up

# Compose down, remove containers and volumes
ExecStop=/usr/bin/docker-compose down -v

[Install]
WantedBy=multi-user.target" | sudo tee /etc/systemd/system/docker-compose@.service > /dev/null

sudo systemctl daemon-reload

sudo rm -rf /work
sudo mkdir -p /work/kafka/zk
sudo mkdir -p /work/kafka/kfk1
sudo mkdir -p /work/kafka/kfk2
sudo mkdir -p /work/kafka/kfk3
sudo chmod -R 777 /work 
cp confluent-6.2.0.zip /work/kafka
pushd /work/kafka
unzip -qq confluent-6.2.0.zip 
rm -f confluent-6.2.0.zip 
popd
rm -rf /work/kafka/zk/*
rm -rf /work/kafka/kfk1/*
rm -rf /work/kafka/kfk2/*
rm -rf /work/kafka/kfk3/*
rm -rf /work/kafka/confluent-6.2.0/logs/*
sudo chmod -R 777 /work

	cp /work/kafka/confluent-6.2.0/etc/kafka/server.properties /work/kafka/confluent-6.2.0/etc/kafka/server1.properties
	cp /work/kafka/confluent-6.2.0/etc/kafka/server.properties /work/kafka/confluent-6.2.0/etc/kafka/server2.properties
	cp /work/kafka/confluent-6.2.0/etc/kafka/server.properties /work/kafka/confluent-6.2.0/etc/kafka/server3.properties
	rm -f /work/kafka/confluent-6.2.0/etc/kafka/server.properties
			
	sed -i -e "s~zookeeper.connect=localhost:2181~zookeeper.connect=$THESYSTEMHOSTNAME:3100~g" /work/kafka/confluent-6.2.0/etc/kafka/server1.properties
	sed -i -e "s~log.dirs=/tmp/kafka-logs~log.dirs=/work/kafka/kfk1~g" /work/kafka/confluent-6.2.0/etc/kafka/server1.properties
	sed -i -e "s~#metric.reporters=io.confluent.metrics.reporter.ConfluentMetricsReporter~metric.reporters=io.confluent.metrics.reporter.ConfluentMetricsReporter~g" /work/kafka/confluent-6.2.0/etc/kafka/server1.properties
	sed -i -e "s~#confluent.metrics.reporter.bootstrap.servers=localhost:9092~confluent.metrics.reporter.bootstrap.servers=$THESYSTEMHOSTNAME:3400,$THESYSTEMHOSTNAME:3401,$THESYSTEMHOSTNAME:3402~g" /work/kafka/confluent-6.2.0/etc/kafka/server1.properties
	echo "confluent.schema.registry.url=http://$THESYSTEMHOSTNAME:3500" >> /work/kafka/confluent-6.2.0/etc/kafka/server1.properties
	sed -i -e "s~#listeners=PLAINTEXT://:9092~listeners=PLAINTEXT://$THESYSTEMHOSTNAME:3400~g" /work/kafka/confluent-6.2.0/etc/kafka/server1.properties
	sed -i -e "s~offsets.topic.replication.factor=1~offsets.topic.replication.factor=3~g" /work/kafka/confluent-6.2.0/etc/kafka/server1.properties
	sed -i -e "s~transaction.state.log.replication.factor=1~transaction.state.log.replication.factor=3~g" /work/kafka/confluent-6.2.0/etc/kafka/server1.properties
	sed -i -e "s~transaction.state.log.min.isr=1~transaction.state.log.min.isr=2~g" /work/kafka/confluent-6.2.0/etc/kafka/server1.properties
	echo "confluent.metadata.server.listeners=http://$THESYSTEMHOSTNAME:3403" >> /work/kafka/confluent-6.2.0/etc/kafka/server1.properties
	
	sed -i -e "s~zookeeper.connect=localhost:2181~zookeeper.connect=$THESYSTEMHOSTNAME:3100~g" /work/kafka/confluent-6.2.0/etc/kafka/server2.properties
	sed -i -e "s~log.dirs=/tmp/kafka-logs~log.dirs=/work/kafka/kfk2~g" /work/kafka/confluent-6.2.0/etc/kafka/server2.properties
	sed -i -e "s~#metric.reporters=io.confluent.metrics.reporter.ConfluentMetricsReporter~metric.reporters=io.confluent.metrics.reporter.ConfluentMetricsReporter~g" /work/kafka/confluent-6.2.0/etc/kafka/server2.properties
	sed -i -e "s~#confluent.metrics.reporter.bootstrap.servers=localhost:9092~confluent.metrics.reporter.bootstrap.servers=$THESYSTEMHOSTNAME:3400,$THESYSTEMHOSTNAME:3401,$THESYSTEMHOSTNAME:3402~g" /work/kafka/confluent-6.2.0/etc/kafka/server2.properties
	echo "confluent.schema.registry.url=http://$THESYSTEMHOSTNAME:3500" >> /work/kafka/confluent-6.2.0/etc/kafka/server2.properties
	sed -i -e "s~#listeners=PLAINTEXT://:9092~listeners=PLAINTEXT://$THESYSTEMHOSTNAME:3401~g" /work/kafka/confluent-6.2.0/etc/kafka/server2.properties
	sed -i -e "s~offsets.topic.replication.factor=1~offsets.topic.replication.factor=3~g" /work/kafka/confluent-6.2.0/etc/kafka/server2.properties
	sed -i -e "s~transaction.state.log.replication.factor=1~transaction.state.log.replication.factor=3~g" /work/kafka/confluent-6.2.0/etc/kafka/server2.properties
	sed -i -e "s~transaction.state.log.min.isr=1~transaction.state.log.min.isr=2~g" /work/kafka/confluent-6.2.0/etc/kafka/server2.properties
	echo "confluent.metadata.server.listeners=http://$THESYSTEMHOSTNAME:3404" >> /work/kafka/confluent-6.2.0/etc/kafka/server2.properties
	
	sed -i -e "s~zookeeper.connect=localhost:2181~zookeeper.connect=$THESYSTEMHOSTNAME:3100~g" /work/kafka/confluent-6.2.0/etc/kafka/server3.properties
	sed -i -e "s~log.dirs=/tmp/kafka-logs~log.dirs=/work/kafka/kfk3~g" /work/kafka/confluent-6.2.0/etc/kafka/server3.properties
	sed -i -e "s~#metric.reporters=io.confluent.metrics.reporter.ConfluentMetricsReporter~metric.reporters=io.confluent.metrics.reporter.ConfluentMetricsReporter~g" /work/kafka/confluent-6.2.0/etc/kafka/server3.properties
	sed -i -e "s~#confluent.metrics.reporter.bootstrap.servers=localhost:9092~confluent.metrics.reporter.bootstrap.servers=$THESYSTEMHOSTNAME:3400,$THESYSTEMHOSTNAME:3401,$THESYSTEMHOSTNAME:3402~g" /work/kafka/confluent-6.2.0/etc/kafka/server3.properties
	echo "confluent.schema.registry.url=http://$THESYSTEMHOSTNAME:3500" >> /work/kafka/confluent-6.2.0/etc/kafka/server3.properties
	sed -i -e "s~#listeners=PLAINTEXT://:9092~listeners=PLAINTEXT://$THESYSTEMHOSTNAME:3402~g" /work/kafka/confluent-6.2.0/etc/kafka/server3.properties
	sed -i -e "s~offsets.topic.replication.factor=1~offsets.topic.replication.factor=3~g" /work/kafka/confluent-6.2.0/etc/kafka/server3.properties
	sed -i -e "s~transaction.state.log.replication.factor=1~transaction.state.log.replication.factor=3~g" /work/kafka/confluent-6.2.0/etc/kafka/server3.properties
	sed -i -e "s~transaction.state.log.min.isr=1~transaction.state.log.min.isr=2~g" /work/kafka/confluent-6.2.0/etc/kafka/server3.properties
	echo "confluent.metadata.server.listeners=http://$THESYSTEMHOSTNAME:3405" >> /work/kafka/confluent-6.2.0/etc/kafka/server3.properties		

	rm -f /work/kafka/confluent-6.2.0/etc/kafka/zookeeper.properties
	echo "tickTime=2000
dataDir=/work/kafka/zk
clientPort=3100
initLimit=5
syncLimit=2
server.1=$THESYSTEMHOSTNAME:3200:3300
autopurge.snapRetainCount=3
autopurge.purgeInterval=24
maxClientCnxns=0" >> /work/kafka/confluent-6.2.0/etc/kafka/zookeeper.properties

	echo "1" >> /work/kafka/zk/myid
	sed -i -e "s~broker.id=0~broker.id=100~g" /work/kafka/confluent-6.2.0/etc/kafka/server1.properties
	sed -i -e "s~broker.id=0~broker.id=200~g" /work/kafka/confluent-6.2.0/etc/kafka/server2.properties
	sed -i -e "s~broker.id=0~broker.id=300~g" /work/kafka/confluent-6.2.0/etc/kafka/server3.properties		

	sudo mkdir -p /work/kafka/prometheus
	sudo rm -rf /work/kafka/prometheus/*
	sudo chmod -R 777 /work
	cd ~	
	sudo cp jmx_prometheus_javaagent-0.15.0.jar /work/kafka/prometheus
	sudo cp kafka-0-8-2.yml /work/kafka/prometheus
	sudo cp zookeeper.yaml /work/kafka/prometheus
	sudo chmod -R 777 /work

	sudo systemctl enable kafka-zookeeper && sudo systemctl start kafka-zookeeper

	sudo systemctl enable kafka-broker1 && sudo systemctl start kafka-broker1
	sudo systemctl enable kafka-broker2 && sudo systemctl start kafka-broker2
	sudo systemctl enable kafka-broker3 && sudo systemctl start kafka-broker3

	sed -i -e "s~listeners=http://0.0.0.0:8081~listeners=http://$THESYSTEMHOSTNAME:3500~g" /work/kafka/confluent-6.2.0/etc/schema-registry/schema-registry.properties
	sed -i -e "s~#kafkastore.connection.url=localhost:2181~kafkastore.connection.url=$THESYSTEMHOSTNAME:3100~g" /work/kafka/confluent-6.2.0/etc/schema-registry/schema-registry.properties
	sed -i -e "s~kafkastore.bootstrap.servers=PLAINTEXT://localhost:9092~#kafkastore.bootstrap.servers=PLAINTEXT://localhost:9092~g" /work/kafka/confluent-6.2.0/etc/schema-registry/schema-registry.properties

	sed -i -e "s~bootstrap.servers=localhost:9092~bootstrap.servers=$THESYSTEMHOSTNAME:3400,$THESYSTEMHOSTNAME:3401,$THESYSTEMHOSTNAME:3402~g" /work/kafka/confluent-6.2.0/etc/kafka/connect-distributed.properties
	sed -i -e "s~#rest.host.name=~rest.host.name=$THESYSTEMHOSTNAME~g" /work/kafka/confluent-6.2.0/etc/kafka/connect-distributed.properties
	sed -i -e "s~#rest.port=8083~rest.port=3600~g" /work/kafka/confluent-6.2.0/etc/kafka/connect-distributed.properties
	echo "consumer.interceptor.classes=io.confluent.monitoring.clients.interceptor.MonitoringConsumerInterceptor" >> /work/kafka/confluent-6.2.0/etc/kafka/connect-distributed.properties
	echo "producer.interceptor.classes=io.confluent.monitoring.clients.interceptor.MonitoringProducerInterceptor" >> /work/kafka/confluent-6.2.0/etc/kafka/connect-distributed.properties

	sed -i -e "s~bootstrap.servers=localhost:9092~bootstrap.servers=$THESYSTEMHOSTNAME:3400,$THESYSTEMHOSTNAME:3401,$THESYSTEMHOSTNAME:3402~g" /work/kafka/confluent-6.2.0/etc/schema-registry/connect-avro-distributed.properties
	sed -i -e "s~#rest.host.name=0.0.0.0~rest.host.name=$THESYSTEMHOSTNAME~g" /work/kafka/confluent-6.2.0/etc/schema-registry/connect-avro-distributed.properties
	sed -i -e "s~#rest.port=8083~rest.port=3600~g" /work/kafka/confluent-6.2.0/etc/schema-registry/connect-avro-distributed.properties
	echo "consumer.interceptor.classes=io.confluent.monitoring.clients.interceptor.MonitoringConsumerInterceptor" >> /work/kafka/confluent-6.2.0/etc/schema-registry/connect-avro-distributed.properties
	echo "producer.interceptor.classes=io.confluent.monitoring.clients.interceptor.MonitoringProducerInterceptor" >> /work/kafka/confluent-6.2.0/etc/schema-registry/connect-avro-distributed.properties
	sed -i -e "s~key.converter.schema.registry.url=http://localhost:8081~key.converter.schema.registry.url=http://$THESYSTEMHOSTNAME:3500~g" /work/kafka/confluent-6.2.0/etc/schema-registry/connect-avro-distributed.properties
	sed -i -e "s~value.converter.schema.registry.url=http://localhost:8081~value.converter.schema.registry.url=http://$THESYSTEMHOSTNAME:3500~g" /work/kafka/confluent-6.2.0/etc/schema-registry/connect-avro-distributed.properties

	sed -i -e "s~#id=kafka-rest-test-server~id=kafka-rest-server~g" /work/kafka/confluent-6.2.0/etc/kafka-rest/kafka-rest.properties
	sed -i -e "s~#schema.registry.url=http://localhost:8081~schema.registry.url=http://$THESYSTEMHOSTNAME:3500~g" /work/kafka/confluent-6.2.0/etc/kafka-rest/kafka-rest.properties
	sed -i -e "s~#zookeeper.connect=localhost:2181~zookeeper.connect=$THESYSTEMHOSTNAME:3100~g" /work/kafka/confluent-6.2.0/etc/kafka-rest/kafka-rest.properties
	sed -i -e "s~bootstrap.servers=PLAINTEXT://localhost:9092~bootstrap.servers=PLAINTEXT://$THESYSTEMHOSTNAME:3400,PLAINTEXT://$THESYSTEMHOSTNAME:3401,PLAINTEXT://$THESYSTEMHOSTNAME:3402~g" /work/kafka/confluent-6.2.0/etc/kafka-rest/kafka-rest.properties
	echo "listeners=http://$THESYSTEMHOSTNAME:3700" >> /work/kafka/confluent-6.2.0/etc/kafka-rest/kafka-rest.properties
	echo "consumer.interceptor.classes=io.confluent.monitoring.clients.interceptor.MonitoringConsumerInterceptor" >> /work/kafka/confluent-6.2.0/etc/kafka-rest/kafka-rest.properties
	echo "producer.interceptor.classes=io.confluent.monitoring.clients.interceptor.MonitoringProducerInterceptor" >> /work/kafka/confluent-6.2.0/etc/kafka-rest/kafka-rest.properties

	sed -i -e "s~bootstrap.servers=localhost:9092~bootstrap.servers=$THESYSTEMHOSTNAME:3400,$THESYSTEMHOSTNAME:3401,$THESYSTEMHOSTNAME:3402~g" /work/kafka/confluent-6.2.0/etc/ksqldb/ksql-server.properties
	sed -i -e "s~listeners=http://0.0.0.0:8088~listeners=http://$THESYSTEMHOSTNAME:3800~g" /work/kafka/confluent-6.2.0/etc/ksqldb/ksql-server.properties
	sed -i -e "s~# ksql.schema.registry.url=http://localhost:8081~ksql.schema.registry.url=http://$THESYSTEMHOSTNAME:3500~g" /work/kafka/confluent-6.2.0/etc/ksqldb/ksql-server.properties
	sed -i -e "s~bootstrap.servers=localhost:9092~bootstrap.servers=$THESYSTEMHOSTNAME:3400,$THESYSTEMHOSTNAME:3401,$THESYSTEMHOSTNAME:3402~g" /work/kafka/confluent-6.2.0/etc/ksqldb/connect.properties
	sed -i -e "s~key.converter.schema.registry.url=http://localhost:8081~key.converter.schema.registry.url=http://$THESYSTEMHOSTNAME:3500~g" /work/kafka/confluent-6.2.0/etc/ksqldb/connect.properties
	sed -i -e "s~value.converter.schema.registry.url=http://localhost:8081~key.converter.schema.registry.url=http://$THESYSTEMHOSTNAME:3500~g" /work/kafka/confluent-6.2.0/etc/ksqldb/connect.properties

	sed -i -e "s~bootstrap.servers=localhost:9092~bootstrap.servers=$THESYSTEMHOSTNAME:3400,$THESYSTEMHOSTNAME:3401,$THESYSTEMHOSTNAME:3402~g" /work/kafka/confluent-6.2.0/etc/confluent-control-center/control-center-minimal.properties
	sed -i -e "s~zookeeper.connect=localhost:2181~zookeeper.connect=$THESYSTEMHOSTNAME:3100~g" /work/kafka/confluent-6.2.0/etc/confluent-control-center/control-center-minimal.properties
	sed -i -e "s~confluent.controlcenter.data.dir=/tmp/confluent/control-center~confluent.controlcenter.data.dir=/work/kafka/ccc~g" /work/kafka/confluent-6.2.0/etc/confluent-control-center/control-center-minimal.properties
	sed -i -e "s~#confluent.controlcenter.connect.<connect-cluster-name>.cluster=http://localhost:8083~confluent.controlcenter.connect.KafkaConnect.cluster=http://$THESYSTEMHOSTNAME:3600~g" /work/kafka/confluent-6.2.0/etc/confluent-control-center/control-center-minimal.properties
	sed -i -e "s~confluent.controlcenter.schema.registry.url=http://localhost:8081~confluent.controlcenter.schema.registry.url=http://$THESYSTEMHOSTNAME:3500~g" /work/kafka/confluent-6.2.0/etc/confluent-control-center/control-center-minimal.properties
	echo "confluent.controlcenter.rest.listeners=http://$THESYSTEMHOSTNAME:4000" >> /work/kafka/confluent-6.2.0/etc/confluent-control-center/control-center-minimal.properties
	sed -i -e "s~#confluent.controlcenter.ksql.<ksql-cluster-name>.url=http://localhost:8088~confluent.controlcenter.ksql.ksqlDB.url=http://$THESYSTEMHOSTNAME:3800~g" /work/kafka/confluent-6.2.0/etc/confluent-control-center/control-center-minimal.properties
	sed -i -e "s~confluent.controlcenter.streams.cprest.url=http://localhost:8090~confluent.controlcenter.streams.cprest.url=http://$THESYSTEMHOSTNAME:3900~g" /work/kafka/confluent-6.2.0/etc/confluent-control-center/control-center-minimal.properties
	
	sudo mkdir -p /work/kafka/ccc
	sudo rm -rf /work/kafka/ccc/*
	sudo chmod -R 777 /work
		
	sudo mkdir -p /work/kafka/chub
	sudo mkdir -p /work/kafka/confluent-6.2.0/connectors
	sudo rm -rf /work/kafka/chub/*
	sudo chmod -R 777 /work
	cp confluent-hub-client-latest.tar.gz /work/kafka/chub
	pushd /work/kafka/chub
	tar xf confluent-hub-client-latest.tar.gz 
	rm -f confluent-hub-client-latest.tar.gz 
	popd
	sudo chmod -R 777 /work
		
	/work/kafka/chub/bin/confluent-hub install confluentinc/kafka-connect-jdbc:10.0.0 --component-dir /work/kafka/confluent-6.2.0/share/java --worker-configs /work/kafka/confluent-6.2.0/etc/schema-registry/connect-avro-distributed.properties	
	
	#/work/kafka/chub/bin/confluent-hub install debezium/debezium-connector-mysql:1.2.2 --component-dir /work/kafka/confluent-6.2.0/share/java --worker-configs /work/kafka/confluent-6.2.0/etc/schema-registry/connect-avro-distributed.properties 
	
	#/work/kafka/chub/bin/confluent-hub install confluentinc/kafka-connect-hdfs3:latest --component-dir /work/kafka/confluent-6.2.0/share/java --worker-configs /work/kafka/confluent-6.2.0/etc/schema-registry/connect-avro-distributed.properties

	sudo cp /usr/share/java/mysql-connector-java.jar /work/kafka/confluent-6.2.0/share/java/mysql-connector-java-5.1.46-bin.jar
	sudo cp /usr/share/java/mysql-connector-java.jar /work/kafka/confluent-6.2.0/share/java/confluentinc-kafka-connect-jdbc/lib/mysql-connector-java-5.1.46-bin.jar
	sudo chmod -R 777 /work
		
	sudo systemctl enable kafka-schema-registry && sudo systemctl start kafka-schema-registry
	sudo systemctl enable kafka-connect && sudo systemctl start kafka-connect
	sudo systemctl enable kafka-rest && sudo systemctl start kafka-rest
	sudo systemctl enable kafka-ksql-server && sudo systemctl start kafka-ksql-server
	sudo systemctl enable kafka-control-center && sudo systemctl start kafka-control-center	 
	
	sudo mkdir -p /etc/docker/compose/zoonavigator
	sudo rm -rf /etc/docker/compose/zoonavigator/*
	echo "version: '2.1'

services:
  web:
    image: elkozmon/zoonavigator-web:latest
    container_name: zoonavigator-web
    ports:
     - \"4200:4200\"
    environment:
      WEB_HTTP_PORT: 4200
      API_HOST: \"api\"
      API_PORT: 4100
    depends_on:
     - api
  api:
    image: elkozmon/zoonavigator-api:latest
    container_name: zoonavigator-api
    environment:
      API_HTTP_PORT: 4100" | sudo tee /etc/docker/compose/zoonavigator/docker-compose.yml > /dev/null	
      	sudo docker pull elkozmon/zoonavigator-api:latest
      	sudo docker pull elkozmon/zoonavigator-web:latest
      	sudo systemctl stop docker-compose@zoonavigator
	sudo systemctl start docker-compose@zoonavigator
	
	sudo mkdir -p /etc/docker/compose/kafka-manager
	sudo rm -rf /etc/docker/compose/kafka-manager/*	
	echo "# /etc/docker/compose/kafka-manager/docker-compose.yml
version: '2.1'
services:
  kafka_manager:
    image: hlebalbau/kafka-manager:latest
    ports:
      - \"4210:9000\"
    environment:
      ZK_HOSTS: \"$THESYSTEMHOSTIP:3100\"
      APPLICATION_SECRET: \"random-secret\"
    command: -Dpidfile.path=/dev/null" | sudo tee /etc/docker/compose/kafka-manager/docker-compose.yml > /dev/null	
	sudo docker pull hlebalbau/kafka-manager:latest
      	sudo systemctl stop docker-compose@kafka-manager
	sudo systemctl start docker-compose@kafka-manager
	
	cd ~
	cd kafka-monitor
	sudo yum install -y java-1.8.0-openjdk-devel
	./gradlew jar	
	cd ..
	sudo chmod 777 setupjdk.sh
	sudo mkdir -p /opt/java/oracle
	sudo ./setupjdk.sh
	sudo rm -rf /work/kafka/monitor
	sudo mv kafka-monitor /work/kafka/monitor
	sed -i -e "s~localhost:9092,localhost:9093~$THESYSTEMHOSTNAME:3400,$THESYSTEMHOSTNAME:3401,$THESYSTEMHOSTNAME:3402~g" /work/kafka/monitor/config/xinfra-monitor.properties	
	sed -i -e "s~localhost:9092~$THESYSTEMHOSTNAME:3400,$THESYSTEMHOSTNAME:3401,$THESYSTEMHOSTNAME:3402~g" /work/kafka/monitor/config/xinfra-monitor.properties
	sed -i -e "s~localhost:2181~$THESYSTEMHOSTNAME:3100~g" /work/kafka/monitor/config/xinfra-monitor.properties		
	sudo chmod -R 777 /work	
	#sudo systemctl enable kafka-monitor && sudo systemctl start kafka-monitor
	
	sudo mkdir -p /work/kafka/prometheus
	sudo rm -rf /work/kafka/prometheus/*
	cd ~	
	sudo cp prometheus-2.27.1.linux-amd64.tar.gz /work/kafka/prometheus
	sudo chmod -R 777 /work	
	cd /work/kafka/prometheus
	tar xf prometheus-2.27.1.linux-amd64.tar.gz
	mv prometheus-2.27.1.linux-amd64 core
	rm -f prometheus-2.27.1.linux-amd64.tar.gz
	cd ~
	rm -f /work/kafka/prometheus/core/prometheus.yml
	echo "global:
 scrape_interval: 10s
 evaluation_interval: 10s
scrape_configs:
 - job_name: 'kafka'
   static_configs:
    - targets:
      - $THESYSTEMHOSTNAME:4220
      - $THESYSTEMHOSTNAME:4221
      - $THESYSTEMHOSTNAME:4222 
 - job_name: 'zookeeper'
   static_configs:
    - targets:
      - $THESYSTEMHOSTNAME:4215" | sudo tee /work/kafka/prometheus/core/prometheus.yml > /dev/null	
      	sudo chmod -R 777 /work
      	sudo systemctl enable kafka-prometheus && sudo systemctl start kafka-prometheus
      	
      	cd ~
      	sudo rm -rf /work/kafka/prometheus/grafana
      	sudo cp grafana-7.5.7.linux-amd64.tar.gz /work/kafka/prometheus
	sudo chmod -R 777 /work	
	cd /work/kafka/prometheus
	tar xf grafana-7.5.7.linux-amd64.tar.gz 
	mv grafana-7.5.7 grafana
	rm -f grafana-7.5.7.linux-amd64.tar.gz
	cd ~
	sed -i '38s/.*/http_port = 4240/' /work/kafka/prometheus/grafana/conf/defaults.ini    
	sed -i '371s/.*/enabled = true/' /work/kafka/prometheus/grafana/conf/defaults.ini
	sed -i '377s/.*/org_role = Admin/' /work/kafka/prometheus/grafana/conf/defaults.ini
	sudo systemctl enable kafka-grafana && sudo systemctl start kafka-grafana		 	
	
	sudo systemctl restart docker
	sudo systemctl restart docker-compose@kafka-manager
	sudo systemctl restart docker-compose@zoonavigator

