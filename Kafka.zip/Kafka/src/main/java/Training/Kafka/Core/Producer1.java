package Training.Kafka.Core;

import java.util.*;

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.StringSerializer;

public class Producer1 
{
    public void run()
    {
    	Properties Config = new Properties();
        
        Config.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,"192.168.42.56:9092,192.168.42.56:9093,192.168.42.56:9094");
        Config.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,StringSerializer.class.getName());
        Config.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,StringSerializer.class.getName());
        // key hash generation => 32-bit murmur2 hash 
        //buffer.memory + Max.block.ms => 32MB,60sec
        Config.setProperty(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG,"true");
        //Config.setProperty(ProducerConfig.TRANSACTIONAL_ID_CONFIG,"T1");
        Config.setProperty(ProducerConfig.ACKS_CONFIG,"all");
        //Config.setProperty(ProducerConfig.ACKS_CONFIG,"none");
        //Config.setProperty(ProducerConfig.ACKS_CONFIG,"leader");
        //max.in.flight.requests NO ISSUE NOW
        Config.setProperty(ProducerConfig.RETRIES_CONFIG,Integer.toString(Integer.MAX_VALUE));
        
        //Config.setProperty(ProducerConfig.COMPRESSION_TYPE_CONFIG,"none");DEFAULT
        //Config.setProperty(ProducerConfig.COMPRESSION_TYPE_CONFIG,"gzip");
        //Config.setProperty(ProducerConfig.COMPRESSION_TYPE_CONFIG,"lz4");
        Config.setProperty(ProducerConfig.COMPRESSION_TYPE_CONFIG,"snappy");
        Config.setProperty(ProducerConfig.LINGER_MS_CONFIG,"5");//0 default
        Config.setProperty(ProducerConfig.BATCH_SIZE_CONFIG,Integer.toString(32*1024));//16kb default	    
        
        KafkaProducer<String, String> KP = new KafkaProducer<String, String>(Config);
        //KP.initTransactions();
        
        for(int Counter = 1;Counter<100;Counter++)
        {
	        ProducerRecord<String, String> PR = 
	        		new ProducerRecord<String, String>("topic1",
	        				"Message No "+ Integer.toString(Counter) +" From Code");
	        
	        KP.send(PR, new Callback() {
				public void onCompletion(RecordMetadata RMD, Exception Ex) {
					if(Ex == null)
					{
						System.out.println("Info Recieved: \n"+
								"Partition:"+RMD.partition()+ "\n"+
								"Offset:"+RMD.offset());
					}
					else {System.out.println("Error : "+Ex.toString());}
				}
	        });
        }
        KP.flush();
        KP.close();
    }
}
