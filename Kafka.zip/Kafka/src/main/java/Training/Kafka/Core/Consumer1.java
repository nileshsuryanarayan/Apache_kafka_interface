package Training.Kafka.Core;

import java.time.Duration;
import java.util.*;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.StringDeserializer;

public class Consumer1 
{
    public void run()
    {
    	Properties Config = new Properties();
        
        Config.setProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,"192.168.42.56:9092,192.168.42.56:9093,192.168.42.56:9094");
        Config.setProperty(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,StringDeserializer.class.getName());
        Config.setProperty(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,StringDeserializer.class.getName());
        Config.setProperty(ConsumerConfig.GROUP_ID_CONFIG,"JavaApp");
        Config.setProperty(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG,"earliest");
        //Config.setProperty(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG,"latest");
        //Config.setProperty(ConsumerConfig.FETCH_MIN_BYTES_CONFIG,"1");
        //Config.setProperty(ConsumerConfig.MAX_POLL_RECORDS_CONFIG,"10");
        //Config.setProperty(ConsumerConfig.MAX_PARTITION_FETCH_BYTES_CONFIG,"1");//MB
        //Config.setProperty(ConsumerConfig.FETCH_MAX_BYTES_CONFIG,"50");//MB
        //Config.setProperty(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG,"false");
        //Config.setProperty(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG,"5000");//ms
        //discuss consumer heartbeat
        
        KafkaConsumer<String, String> KC = new KafkaConsumer<String, String>(Config);
        
        KC.subscribe(Arrays.asList("topic1"));
        //KC.subscribe(Arrays.asList("topic1","topic2"));
        
        /*TopicPartition TP = new TopicPartition("topic4",1);
        KC.assign(Arrays.asList(TP));
        //KC.assign(Arrays.asList(TP,TP2));
        long OffsetStartPoint = 0L;
        KC.seek(TP, OffsetStartPoint);*/
        
        while(true) {
        	ConsumerRecords<String,String> CRS = KC.poll(Duration.ofMillis(100));
	        	for(ConsumerRecord<String,String> CR : CRS) {
					System.out.println(
							"Key : "+CR.key()+ " "+
							"Value : "+CR.value()+ " "+
							"Partition : "+CR.partition()+ " "+
							"Offset:"+CR.offset()+ "\n");
	        	}
	        	//KC.commitSync();
        }
    }
}
