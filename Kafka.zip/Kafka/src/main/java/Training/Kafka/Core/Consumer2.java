package Training.Kafka.Core;

import org.apache.kafka.clients.consumer.ConsumerRebalanceListener;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public class Consumer2 {

    public void run() throws InterruptedException {
        ExecutorService executorService = Executors.newFixedThreadPool(3);
        for (int i = 0; i < 3; i++) {
            int finalI = i;
            executorService.execute(() -> startConsumer("consumer-" + finalI));
            Thread.sleep(3000);
        }
        executorService.shutdown();
        executorService.awaitTermination(3, TimeUnit.MINUTES);
    }
    
    static Properties getConsumerProps() {
        Properties props = new Properties();
        props.setProperty("bootstrap.servers", "bigdatakafka-164-52-214-72-e2e7-69967-ncr.cluster:3400,bigdatakafka-164-52-214-73-e2e7-69968-ncr.cluster:3400,bigdatakafka-164-52-214-74-e2e7-69969-ncr.cluster:3400,bigdatakafka-164-52-214-75-e2e7-69970-ncr.cluster:3400");
        props.setProperty("group.id", "Consumer2");
        props.setProperty("enable.auto.commit", "false");
        props.setProperty("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.setProperty("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        return props;
    }
    
    private static KafkaConsumer<String, String> startConsumer(String name) {
        Properties consumerProps = getConsumerProps();
        KafkaConsumer<String, String> consumer = new KafkaConsumer<>(consumerProps);
        consumer.subscribe(Collections.singleton("topic1"),
                new ConsumerRebalanceListener() {
                    @Override
                    public void onPartitionsRevoked(Collection<TopicPartition> partitions) {
                        System.out.printf("onPartitionsRevoked - consumerName: %s, partitions: %s%n", name,
                                formatPartitions(partitions));
                    }

                    @Override
                    public void onPartitionsAssigned(Collection<TopicPartition> partitions) {
                        System.out.printf("onPartitionsAssigned - consumerName: %s, partitions: %s%n", name,
                                formatPartitions(partitions));
                    }
                });
        System.out.printf("starting consumerName: %s%n", name);
        consumer.poll(Duration.ofSeconds(10));
        System.out.printf("closing consumerName: %s%n", name);
        consumer.close();
        return consumer;
    }

    private static List<String> formatPartitions(Collection<TopicPartition> partitions) {
        return partitions.stream().map(topicPartition ->
                String.format("topic: %s, partition: %s", topicPartition.topic(), topicPartition.partition()))
                         .collect(Collectors.toList());
    }
}
