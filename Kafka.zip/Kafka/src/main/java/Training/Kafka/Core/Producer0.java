package Training.Kafka.Core;

import java.util.*;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.StringSerializer;

import Training.Kafka.*;

public class Producer0 
{
    public void run() throws InterruptedException, ExecutionException
    {
    	Properties Config = new Properties();
        
        Config.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,"bigdatakafka-164-52-214-72-e2e7-69967-ncr.cluster:3400,bigdatakafka-164-52-214-73-e2e7-69968-ncr.cluster:3400,bigdatakafka-164-52-214-74-e2e7-69969-ncr.cluster:3400,bigdatakafka-164-52-214-75-e2e7-69970-ncr.cluster:3400");
        Config.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,StringSerializer.class.getName());
        Config.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,StringSerializer.class.getName());
 
        KafkaProducer<String, String> KP = new KafkaProducer<String, String>(Config);
        
        for(int Counter = 1;Counter<1100;Counter++)
        {
	        ProducerRecord<String, String> PR = 
	        		new ProducerRecord<String, String>("topic1",
	        				"Message No "+ Integer.toString(Counter) +" From Code");
	        //KP.send(PR).get();
	        new MetricsProducerReporter(KP).run();
	        KP.send(PR, new Callback() {
				public void onCompletion(RecordMetadata RMD, Exception Ex) {
					if(Ex == null)
					{
						System.out.println("Info Recieved: \n"+
								"Partition:"+RMD.partition()+ "\n"+
								"Offset:"+RMD.offset());
					}
					else {System.out.println("Error : "+Ex.toString());}
				}
	        });
        }
        KP.flush();
        KP.close();
    }
}
