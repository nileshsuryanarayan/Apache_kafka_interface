package Training.Kafka.Stream;

import java.util.Properties;
import java.util.concurrent.CountDownLatch;
import java.util.Arrays;
import java.util.Locale;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.Grouped;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KTable;
import org.apache.kafka.streams.kstream.Produced;

public class AbkiBaar_Sarkar {

    public void run() {
        Properties config = new Properties();
        String Name = "AbkiBaar_Sarkar";
        config.put(StreamsConfig.APPLICATION_ID_CONFIG, Name);
        config.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "bigdatakafka-164-52-214-72-e2e7-69967-ncr.cluster:3400,bigdatakafka-164-52-214-73-e2e7-69968-ncr.cluster:3400,bigdatakafka-164-52-214-74-e2e7-69969-ncr.cluster:3400,bigdatakafka-164-52-214-75-e2e7-69970-ncr.cluster:3400");
        config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        config.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass());
        config.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass());

        final StreamsBuilder builder = new StreamsBuilder();

        final KStream<String, String> source = builder.stream("Elections");

        KStream<String, String> CurentlyLeading = source
                .filter((key, value) -> value.contains("-"))
                .selectKey((key, value) -> value.split("-")[0].toUpperCase())
                .mapValues(value -> value.split("-")[1])
                .filter((key, value) -> value != null);
        
        CurentlyLeading.to("CurentlyLeading");
        
        final KTable<String, Integer> CurentlyLeadingCounts = 
        		CurentlyLeading
        		.map((k, v) -> new KeyValue<>(k, Integer.parseInt(v)))
                .groupByKey(Grouped.with(Serdes.String(), Serdes.Integer()))
                .reduce(Integer::sum);        

        CurentlyLeadingCounts.toStream().
        filter((party, lead) -> Arrays.asList("AITC", "CPM", "BJP", "INC").contains(party))
        .filter((key, value) -> value != null).to(Name, 
        		Produced.with(Serdes.String(), Serdes.Integer()));

        final KafkaStreams streams = new KafkaStreams(builder.build(), config);
        final CountDownLatch latch = new CountDownLatch(1);

        Runtime.getRuntime().addShutdownHook(new Thread(Name+"Stop") {
            @Override
            public void run() {
                streams.close();
                latch.countDown();
            }
        });

        try {
            streams.start();
            latch.await();
        } catch (final Throwable e) {
            System.exit(1);
        }
        System.exit(0);
    }
}
