package Training.Kafka.Stream;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KTable;
import org.apache.kafka.streams.kstream.Produced;

import java.util.Arrays;
import java.util.Properties;
import java.util.concurrent.CountDownLatch;

public final class RetailCurrencySolve {

    public Topology MakeTopology(){
		StreamsBuilder builder = new StreamsBuilder();
		/*//23,45~INR
		// Step 1 -> create stream from kafka	
		KStream<String, String> source = builder.stream("payment");
		KStream<String, String> k2 = source.mapValues(textLine -> converttoproper(textLine));
		k2.filter((key, value) -> value != null).to("realpayment", 
        		Produced.with(Serdes.String(), Serdes.Long()));	*/	
		
		return builder.build();
    }
    
	private Object converttoproper(String textLine) {
		// TODO Auto-generated method stub
		return null;
	}

	public void run() {
        final Properties props = new Properties();
        props.put(StreamsConfig.APPLICATION_ID_CONFIG, "RetailCurrencySolve");
        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "bigdatakafka-164-52-214-72-e2e7-69967-ncr.cluster:3400,bigdatakafka-164-52-214-73-e2e7-69968-ncr.cluster:3400,bigdatakafka-164-52-214-74-e2e7-69969-ncr.cluster:3400,bigdatakafka-164-52-214-75-e2e7-69970-ncr.cluster:3400");
        props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
        props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
        //props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, MyOwnCustomORAvroSerializer.class); 
        //props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, MyOwnCustomORAvroSerializer.class);        
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        //props.put(StreamsConfig.NUM_STREAM_THREADS_CONFIG, "3");
        //Exactly Once Semantics
        //props.put(StreamsConfig.PROCESSING_GUARANTEE_CONFIG, StreamsConfig.EXACTLY_ONCE);
        
        final KafkaStreams streams = new KafkaStreams(MakeTopology(), props);
        final CountDownLatch latch = new CountDownLatch(1);

        Runtime.getRuntime().addShutdownHook(new Thread("RetailCurrencySolveStop") {
            @Override
            public void run() {
            	streams.close();
                latch.countDown();
            }
        });

        try {
            streams.start();   
            //Runtime.getRuntime().addShutdownHook(new Thread(streams::close));
            latch.await();            
            while(true){
                streams.localThreadsMetadata().forEach(data -> System.out.println(data));
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    break;
                }
            }            
        } catch (final Throwable e) {
            System.exit(1);
        }
        System.exit(0);
    }
}