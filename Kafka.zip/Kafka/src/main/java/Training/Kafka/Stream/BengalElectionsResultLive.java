package Training.Kafka.Stream;

import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringSerializer;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

public class BengalElectionsResultLive {
	private static int GetRandomNumber(int F, int S) {

		return (int)(Math.random() * ((S - F) + 1)) + F;
	}
	
	public void run() throws ExecutionException, InterruptedException {

        String bootstrapServers = "bigdatakafka-164-52-214-72-e2e7-69967-ncr.cluster:3400,bigdatakafka-164-52-214-73-e2e7-69968-ncr.cluster:3400,bigdatakafka-164-52-214-74-e2e7-69969-ncr.cluster:3400,bigdatakafka-164-52-214-75-e2e7-69970-ncr.cluster:3400";

        Properties properties = new Properties();
        properties.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        properties.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        properties.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());

        KafkaProducer<String, String> producer = new KafkaProducer<String, String>(properties);
        
        String[] Parties = {"AITC", "GJM", "BJP", "INC", "CPI", "CPM", "GNLF", "RSP", "AIMIM"};
        String[] Cities = {"Kolkata","Asansol","Siliguri","Durgapur","Bardhaman","English Bazar","Baharampur","Habra",
        		"Kharagpur","Shantipur","Dankuni","Dhulian","Ranaghat","Haldia","Raiganj","Krishnanagar",
        		"Nabadwip","Medinipur","Jalpaiguri","Balurghat","Basirhat","Bankura","Chakdaha",
        		"Darjeeling","Alipurduar","Purulia","Jangipur","Bangaon","Cooch Behar"};
        Random r = new Random();
        
        for (int i=0; i<=10000; i++ ) {
        	TimeUnit.MILLISECONDS.sleep(500);
            String topic = "Elections";
            String Lead = Integer.toString(GetRandomNumber(1, 5));
            String City = Cities[r.nextInt(Cities.length)];
            String Party = Parties[r.nextInt(Parties.length)];            

            ProducerRecord<String, String> record =
                    new ProducerRecord<String, String>(topic, City, Party+"-"+Lead);

            producer.send(record, new Callback() {
                public void onCompletion(RecordMetadata recordMetadata, Exception e) {
                    if (e == null) {
                        System.out.println("MetaData Generated... \n" +
                                "Topic:" + recordMetadata.topic() + "\n" +
                                "Partition: " + recordMetadata.partition() + "\n" +
                                "Offset: " + recordMetadata.offset() + "\n" +
                                "Timestamp: " + recordMetadata.timestamp());
                    } else {
                    	System.out.println("Exception : "+ e.toString());
                    }
                }
            });
        }

        producer.flush();
        producer.close();
    }
}