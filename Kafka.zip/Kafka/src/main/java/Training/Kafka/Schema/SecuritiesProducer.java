package Training.Kafka.Schema;

import io.confluent.kafka.serializers.*;
import io.confluent.kafka.serializers.subject.*;

import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.header.internals.RecordHeader;
import org.apache.kafka.common.serialization.StringSerializer;

import Training.Kafka.*;

import java.io.IOException;
import java.util.Properties;

public class SecuritiesProducer {
	 
    private static final String TOPIC = "Security";
 
    public void run() throws IOException {
        Properties properties = new Properties();
        properties.setProperty("bootstrap.servers", "bigdatakafka-164-52-214-72-e2e7-69967-ncr.cluster:3400,bigdatakafka-164-52-214-73-e2e7-69968-ncr.cluster:3400,bigdatakafka-164-52-214-74-e2e7-69969-ncr.cluster:3400,bigdatakafka-164-52-214-75-e2e7-69970-ncr.cluster:3400");
        properties.setProperty("key.serializer", StringSerializer.class.getName());
        properties.setProperty("value.serializer", KafkaAvroSerializer.class.getName());
        properties.setProperty("schema.registry.url", "http://bigdatakafka-164-52-214-76-e2e7-69971-ncr.cluster:3500");
        properties.setProperty("value.subject.name.strategy", TopicRecordNameStrategy.class.getName());

        Producer<String, MF> producer1 = new KafkaProducer<String, MF>(properties);
        Producer<String, Shares> producer2 = new KafkaProducer<String, Shares>(properties);
        
        MF mf = MF.newBuilder().setMfmanager("Karvy").setCurrentnav(350).build();
        Shares shares = Shares.newBuilder().setSharecode("RIL").setCompany("MukeshBhai").build();
        
        ProducerRecord<String, MF> producerRecord1 = new ProducerRecord<String, MF>(TOPIC, mf);  
        producerRecord1.headers().add(new RecordHeader("Type","MF".getBytes()));
        ProducerRecord<String, Shares> producerRecord2 = new ProducerRecord<String, Shares>(TOPIC, shares);         
        producerRecord2.headers().add(new RecordHeader("Type","Share".getBytes()));
        
        producer1.send(producerRecord1, new Callback() {
			public void onCompletion(RecordMetadata RMD, Exception Ex) {
				if(Ex == null)
				{
					System.out.println("Info Recieved: \n"+
							"Partition:"+RMD.partition()+ "\n"+
							"Offset:"+RMD.offset());
				}
				else {System.out.println("Error : "+Ex.toString());}
			}
        });
        
        producer2.send(producerRecord2, new Callback() {
			public void onCompletion(RecordMetadata RMD, Exception Ex) {
				if(Ex == null)
				{
					System.out.println("Info Recieved: \n"+
							"Partition:"+RMD.partition()+ "\n"+
							"Offset:"+RMD.offset());
				}
				else {System.out.println("Error : "+Ex.toString());}
			}
        });
         
        producer1.flush();producer1.close();
        producer2.flush();producer2.close();
        
    	Properties Config2 = new Properties();        
    	Config2.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,"bigdatakafka-164-52-214-72-e2e7-69967-ncr.cluster:3400,bigdatakafka-164-52-214-73-e2e7-69968-ncr.cluster:3400,bigdatakafka-164-52-214-74-e2e7-69969-ncr.cluster:3400,bigdatakafka-164-52-214-75-e2e7-69970-ncr.cluster:3400");
    	Config2.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,StringSerializer.class.getName());
    	Config2.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,StringSerializer.class.getName());     
        KafkaProducer<String, String> KP = new KafkaProducer<String, String>(Config2);        
        ProducerRecord<String, String> PR = new ProducerRecord<String, String>(TOPIC,"US","message1");
        KP.send(PR, new Callback() {public void onCompletion(RecordMetadata RMD, Exception Ex) 
        {if(Ex == null){System.out.println("Info Recieved: \n"+"Partition:"+RMD.partition()+ "\n"+"Offset:"+RMD.offset()+ "\n");}
        else {System.out.println("Error : "+Ex.toString());}}});
        KP.flush();
        KP.close();        
    }
}