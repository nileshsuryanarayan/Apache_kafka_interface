package Training.Kafka.Schema;

import io.confluent.kafka.serializers.KafkaAvroSerializer;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringSerializer;

import Training.Kafka.*;

import java.util.Properties;

public class Producer4 {

    public void run() {
        Properties properties = new Properties();
        properties.setProperty("bootstrap.servers", "bigdatakafka-164-52-214-72-e2e7-69967-ncr.cluster:3400,bigdatakafka-164-52-214-73-e2e7-69968-ncr.cluster:3400,bigdatakafka-164-52-214-74-e2e7-69969-ncr.cluster:3400,bigdatakafka-164-52-214-75-e2e7-69970-ncr.cluster:3400");
        properties.setProperty("key.serializer", StringSerializer.class.getName());
        properties.setProperty("value.serializer", KafkaAvroSerializer.class.getName());
        properties.setProperty("schema.registry.url", "http://bigdatakafka-164-52-214-76-e2e7-69971-ncr.cluster:3500");

        Producer<String, Customer> producer = new KafkaProducer<String, Customer>(properties);

        String topic = "Customer";

        Customer customer = Customer.newBuilder()
                .setAge(35)
                .setFirstName("Bruce")
                .setLastName("Wayne")
                .setMobile(1234)
                .setCustomerAddress(new CustomerAddress("Wayne Street","Gotham"))
                .build();

        ProducerRecord<String, Customer> producerRecord = new ProducerRecord<String, Customer>(
                topic, customer
        );

        System.out.println(customer);
        producer.send(producerRecord, new Callback() {
            @Override
            public void onCompletion(RecordMetadata metadata, Exception exception) {
                if (exception == null) {
                    System.out.println(metadata);
                } else {
                    exception.printStackTrace();
                }
            }
        });

        producer.flush();
        producer.close();
        
    	Properties Config2 = new Properties();        
    	Config2.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,"bigdatakafka-164-52-214-72-e2e7-69967-ncr.cluster:3400,bigdatakafka-164-52-214-73-e2e7-69968-ncr.cluster:3400,bigdatakafka-164-52-214-74-e2e7-69969-ncr.cluster:3400,bigdatakafka-164-52-214-75-e2e7-69970-ncr.cluster:3400");
    	Config2.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,StringSerializer.class.getName());
    	Config2.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,StringSerializer.class.getName());     
        KafkaProducer<String, String> KP = new KafkaProducer<String, String>(Config2);        
        ProducerRecord<String, String> PR = new ProducerRecord<String, String>("Customer","US","message1");
        KP.send(PR, new Callback() {public void onCompletion(RecordMetadata RMD, Exception Ex) 
        {if(Ex == null){System.out.println("Info Recieved: \n"+"Partition:"+RMD.partition()+ "\n"+"Offset:"+RMD.offset()+ "\n");}
        else {System.out.println("Error : "+Ex.toString());}}});
        KP.flush();
        KP.close();        
    }
}
