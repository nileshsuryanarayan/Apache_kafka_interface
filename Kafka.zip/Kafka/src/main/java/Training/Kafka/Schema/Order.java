package Training.Kafka.Schema;

import java.io.Serializable;

public class Order implements Serializable {

	  private int OrderId;
	  private String ItemName;	
	  private String ItemDesc;	
	  private int AmountTotal;	  

	  public Order() {
	  }

	  public Order(int OrderId, String ItemName, String ItemDesc, int AmountTotal) {
	    this.OrderId = OrderId;
	    this.ItemName = ItemName;	    
	    this.AmountTotal = AmountTotal;
	    this.ItemDesc = ItemDesc;
	  }
	  public String getItemDesc() {
		    return this.ItemDesc;
		  }
	  public int getOrderId() {
	    return this.OrderId;
	  }

	  public String getItemName() {
		    return this.ItemName;
		  }
	  	  
	  public int getAmountTotal() {
	    return this.AmountTotal;
	  }	  
	  public void setItemDesc(String ItemDesc) {
		    this.ItemDesc = ItemDesc;
		  }
	  public void setAmountTotal(int AmountTotal) {
	    this.AmountTotal = AmountTotal;
	  }
	  
	  public void setOrderId(int OrderId) {
		    this.OrderId = OrderId;
		  }

	  public void setItemName(String ItemName) {
		    this.ItemName = ItemName;
		  }
	  
	  @Override public String toString() {
	    return OrderId+"-"+ItemName+"-"+ItemDesc+"-"+AmountTotal;
	  }
	}