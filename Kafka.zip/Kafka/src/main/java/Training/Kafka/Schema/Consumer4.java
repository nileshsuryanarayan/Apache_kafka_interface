package Training.Kafka.Schema;

import java.time.Duration;
import java.util.*;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.common.serialization.StringDeserializer;

public class Consumer4 
{
    public void run()
    {
    	Properties Config = new Properties();
        
        Config.setProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,"bigdatakafka-164-52-214-72-e2e7-69967-ncr.cluster:3400,bigdatakafka-164-52-214-73-e2e7-69968-ncr.cluster:3400,bigdatakafka-164-52-214-74-e2e7-69969-ncr.cluster:3400,bigdatakafka-164-52-214-75-e2e7-69970-ncr.cluster:3400");
        Config.setProperty(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,StringDeserializer.class.getName());
        Config.setProperty(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,OrderDeserializer.class.getName());
        Config.setProperty(ConsumerConfig.GROUP_ID_CONFIG,"Consumer4741");
        Config.setProperty(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG,"earliest");
        
        KafkaConsumer<String, Order> KC = new KafkaConsumer<String, Order>(Config);
        
        KC.subscribe(Arrays.asList("topic2"));
               
        while(true) {
        	ConsumerRecords<String,Order> CRS = KC.poll(Duration.ofMillis(100));
	        	for(ConsumerRecord<String,Order> CR : CRS) {
	        		System.out.println(CR);
	        	}
        }
    }
}
