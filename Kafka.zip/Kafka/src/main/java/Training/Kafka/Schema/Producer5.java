package Training.Kafka.Schema;

import java.util.*;

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.StringSerializer;

public class Producer5 
{
    public void run()
    {
    	Properties Config = new Properties();
        
        Config.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,"bigdatakafka-164-52-214-72-e2e7-69967-ncr.cluster:3400,bigdatakafka-164-52-214-73-e2e7-69968-ncr.cluster:3400,bigdatakafka-164-52-214-74-e2e7-69969-ncr.cluster:3400,bigdatakafka-164-52-214-75-e2e7-69970-ncr.cluster:3400");
        Config.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,StringSerializer.class.getName());
        Config.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,OrderSerializer.class.getName());
        
        KafkaProducer<String, Order> KP = new KafkaProducer<String, Order>(Config);
        
        Order o = new Order();
        o.setOrderId(5);
        o.setItemName("Fridge");
        o.setAmountTotal(70000);
        o.setItemDesc("Godrej");
        ProducerRecord<String, Order> PR = new ProducerRecord<String, Order>("topic2","qwertyuio",o);
        KP.send(PR, new Callback() {public void onCompletion(RecordMetadata RMD, Exception Ex) 
        {if(Ex == null){System.out.println("Info Recieved: \n"+"Partition:"+RMD.partition()+ "\n"+"Offset:"+RMD.offset()+ "\n");}
        else {System.out.println("Error : "+Ex.toString());}}});

        KP.flush();
        KP.close();
    }
}
