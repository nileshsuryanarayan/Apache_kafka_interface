package Training.Kafka.Schema;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Map;
import org.apache.kafka.common.serialization.Serializer;
import com.fasterxml.jackson.databind.ObjectMapper;

public class OrderSerializer implements Serializer<Order>
{
    private boolean isKey;

    @Override
    public void configure(Map<String, ?> configs, boolean isKey)
    {
        this.isKey = isKey;
    }

    @Override
    public byte[] serialize(String topic, Order data)
    {
        byte[] retVal = null;
        
        ObjectMapper objectMapper = new ObjectMapper();
        try {
          //retVal = objectMapper.writeValueAsString(data).getBytes();
          retVal = objectMapper.writeValueAsBytes(data);
        } catch (Exception e) {
          e.printStackTrace();
        }
        
        /*ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream out = null;
        try {
          out = new ObjectOutputStream(bos);   
          out.writeObject(data);
          out.flush();
          retVal = bos.toByteArray();
        } catch (IOException e) {
			e.printStackTrace();
		} finally {
          try {
            bos.close();
          } catch (IOException ex) {}
        }*/                            
        return retVal;
      }

    @Override
    public void close()
    {

    }
}