package Training.Kafka;

import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringSerializer;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

public class PuttingPetrolIntoFire {
	private static int GetRandomNumber(int F, int S) {

		return (int)(Math.random() * ((S - F) + 1)) + F;
	}
	
	public void run() throws ExecutionException, InterruptedException {

        String bootstrapServers = "192.168.42.56:9092,192.168.42.56:9093,192.168.42.56:9094";

        Properties properties = new Properties();
        properties.put("topic.metadata.refresh.interval.ms", "10");
        properties.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        properties.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        properties.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());

        KafkaProducer<String, String> producer = new KafkaProducer<String, String>(properties);
        
        String[] V = {"1", "2", "3", "4", "5", "6", "7", "8", "9"};
        String[] K = {"A","B","C","D","E","F","G","H","I",
        		"J","K","L","M","N","O","P","Q","R","S","T","U",
        		"V","W","X","Y","Z"};
        Random R = new Random();
        int Counter = 0;
        
        for (int i=0; i<=10000; i++ ) {
        	Counter = Counter+1;
        	TimeUnit.MILLISECONDS.sleep(100);
            String topic = "topic3";
            String r = "0";
            if(Counter>500) {r = Integer.toString(GetRandomNumber(60, 150));}else{r = Integer.toString(GetRandomNumber(1, 5));}
            String k = K[R.nextInt(K.length)];
            String v = V[R.nextInt(V.length)];            

            ProducerRecord<String, String> record =
                    new ProducerRecord<String, String>(topic, r, k+"-"+v);

            producer.send(record, new Callback() {
                public void onCompletion(RecordMetadata recordMetadata, Exception e) {
                    if (e == null) {
                        System.out.println("MetaData Generated... \n" +
                                "Topic:" + recordMetadata.topic() + "\n" +
                                "Partition: " + recordMetadata.partition() + "\n" +
                                "Offset: " + recordMetadata.offset() + "\n" +
                                "Timestamp: " + recordMetadata.timestamp());
                    } else {
                    	System.out.println("Exception : "+ e.toString());
                    }
                }
            });
        }

        producer.flush();
        producer.close();
    }
}